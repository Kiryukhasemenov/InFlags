# InFlags
Python package for dictionary-based inline tokenization preprocessing

## Installation

## InCa - Inline Casing

## InDia - Inline Diacritization